let progress = 0;

function updateProgress() {
  if (progress < 100) {
    progress += 20;
    document.getElementById("progress").innerText = `${progress}%`;
  } else {
    alert("Course already completed!");
  }
}
